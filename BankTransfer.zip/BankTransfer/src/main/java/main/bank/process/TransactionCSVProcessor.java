package main.bank.process;

import java.io.IOException;
import java.io.Reader;
import java.math.BigDecimal;
import java.util.HashMap;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import main.bank.bean.CSVObject;
import main.bank.bean.CSVObjectBuilder;

public class TransactionCSVProcessor extends TransferProcessor {

  private CSVObjects processedObj;

  public TransactionCSVProcessor(Reader reader, CSVObjects processedObj) {
    super(reader);
    this.processedObj = processedObj;
  }

  /**
   * spracovava vstup po jednotlivych riadkoch a agreguje hodnoty podla kluca
   */
  @Override
  public HashMap<String, Object> process() throws Exception {
    HashMap<String, Object> result = new HashMap<String, Object>();
    try {
      for (CSVRecord record : new CSVParser(reader, CSVFormat.DEFAULT.withHeader(processedObj.getHeader()).withFirstRecordAsHeader())) {
        CSVObject obj = CSVObjectBuilder.build(processedObj.clazz, record);

        if (result.get(obj.getKey()) == null)
          result.put(obj.getKey(), new TransactionsAmount());

        ((TransactionsAmount) result.get(obj.getKey())).aggregateObject(obj);
      }
      return result;
    } catch (IOException e) {
      throw new Exception("Chyba pri citani vstupnych dat.", e);
    }
  }

  public static class TransactionsAmount {

    private int count;
    private BigDecimal amount;

    public int getCount() {
      return count;
    }

    public void setCount(int count) {
      this.count = count;
    }

    public BigDecimal getAmount() {
      return amount;
    }

    public void setAmount(BigDecimal amount) {
      this.amount = amount;
    }

    @Override
    public String toString() {
      return count + " items | total amount: " + amount + " EUR";
    }

    public void aggregateObject(CSVObject obj) {
      count++;

      if (amount == null)
        amount = BigDecimal.ZERO;

      amount = amount.add(obj.getAggregatePrice());
    }
  }
}
