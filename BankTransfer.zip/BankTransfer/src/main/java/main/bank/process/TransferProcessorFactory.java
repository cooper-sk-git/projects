package main.bank.process;

import java.io.Reader;

import main.bank.process.TransferProcessor.CSVObjects;

public class TransferProcessorFactory {

  public TransferProcessor getProcessor(Reader reader, CSVObjects obj, TransferProcessor.Format format) throws Exception {
    if (TransferProcessor.CSVObjects.TRANSACTION.equals(obj) && TransferProcessor.Format.CSV.equals(format))
      return new TransactionCSVProcessor(reader, obj);

    throw new Exception("Neznamy typ zdroja pre spracovanie.");
  }
}
