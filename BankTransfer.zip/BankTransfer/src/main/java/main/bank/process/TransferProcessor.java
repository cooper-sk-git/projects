package main.bank.process;

import java.io.Reader;
import java.util.HashMap;

import main.bank.bean.CSVObject;
import main.bank.bean.Transaction;

public abstract class TransferProcessor {
  
  protected Reader reader;
  
  public TransferProcessor(Reader reader) {
    this.reader = reader;
  }
  
  abstract public HashMap<String, Object> process() throws Exception;
  
  public enum CSVObjects {
    TRANSACTION(Transaction.class.getName(), Transaction.class){
      @Override
      public String[] getHeader() {
        return Transaction.HEADER;
      }
    };

    public String name;
    public Class<? extends CSVObject> clazz;
    
    private CSVObjects(String name, Class<? extends CSVObject> clazz) {
      this.name = name;
      this.clazz = clazz;
    }
    
    public abstract String[] getHeader();
  }
  
  public enum Format {
    CSV, XML
  }
  
}
