package main.bank.bean;

import java.math.BigDecimal;
import java.sql.Date;

public class Transaction extends CSVObject {

  public static final String[] HEADER = new String[] { "id", "accounttype", "currency", "date", "description", "amount", "debit", "label" };

  @CSVObjectDoc(name = "id")
  private int id;
  @CSVObjectDoc(name = "accounttype")
  private String accounttype;
  @CSVObjectDoc(name = "currency")
  private String currency;
  @CSVObjectDoc(name = "date")
  private Date date;
  @CSVObjectDoc(name = "description")
  private String description;
  @CSVObjectDoc(name = "amount")
  private BigDecimal amount;
  @CSVObjectDoc(name = "debit")
  private boolean debit;
  @CSVObjectDoc(name = "label")
  private String label;

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getAccounttype() {
    return accounttype;
  }

  public void setAccounttype(String accounttype) {
    this.accounttype = accounttype;
  }

  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public Date getDate() {
    return date;
  }

  public void setDate(Date date) {
    this.date = date;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public BigDecimal getAmount() {
    return amount;
  }

  public void setAmount(BigDecimal amount) {
    this.amount = amount;
  }

  public boolean isDebit() {
    return debit;
  }

  public void setDebit(boolean debit) {
    this.debit = debit;
  }

  public String getLabel() {
    return label;
  }

  public void setLabel(String label) {
    this.label = label;
  }
  
  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder("[ ");
    sb.append(id).append(", ");
    sb.append(accounttype).append(", ");
    sb.append(currency).append(", ");
    sb.append(date).append(", ");
    sb.append(description).append(", ");
    sb.append(amount).append(", ");
    sb.append(debit).append(", ");
    sb.append(label).append(" ]");
    return sb.toString();
  }

  @Override
  public String getKey() {
    return label;
  }

  @Override
  public BigDecimal getAggregatePrice() {
    return amount;
  }

}
