package main.bank.bean;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.SimpleDateFormat;

import org.apache.commons.csv.CSVRecord;

public class CSVObjectBuilder {
  
  /**
   * mapovanie hodnot zaznamu zo vstupu na atributy objektu podla zhody v anotacii.
   * cielom je, aby namapovalo to co vie (v pripade ze nam pride zmeneny/doplneny subor)
   * @param clazz
   * @param record
   * @return
   * @throws Exception
   */
  public static CSVObject build(Class<? extends CSVObject> clazz, CSVRecord record) throws Exception {
    try {
      CSVObject obj = clazz.newInstance();
      for (Field field : clazz.getDeclaredFields()) {
        field.setAccessible(true);
        if (field.isAnnotationPresent(CSVObjectDoc.class)) {
          try {
            if (field.getType().equals(Integer.class) || field.getType().equals(int.class))
              field.set(obj, Integer.parseInt(record.get(field.getAnnotation(CSVObjectDoc.class).name())));
            else if (field.getType().equals(String.class))
              field.set(obj, record.get(field.getAnnotation(CSVObjectDoc.class).name()).toString());
            else if (field.getType().equals(Date.class))
              field.set(obj, new java.sql.Date(new SimpleDateFormat("YYYY-MM-DD").parse(record.get(field.getAnnotation(CSVObjectDoc.class).name())).getTime()));
            else if (field.getType().equals(Boolean.class) || field.getType().equals(boolean.class))
              field.set(obj, Boolean.parseBoolean(record.get(field.getAnnotation(CSVObjectDoc.class).name())));
            else if (field.getType().equals(BigDecimal.class) )
              field.set(obj, new BigDecimal(record.get(field.getAnnotation(CSVObjectDoc.class).name())));
            else
              throw new Exception("Neznamy datovy typ.");
          } catch (Exception e) {
            throw new Exception("Chyba pri mapovani atributu " + field.getName() + " na hodnotu " + record.get(field.getAnnotation(CSVObjectDoc.class).name()), e);
          }
        }
      }
      return obj;
    } catch (Exception e) {
      throw new Exception("Chyba pri mapovani objektu " + clazz.getSimpleName(), e);
    }
  }

}
