package main.bank.bean;

import java.math.BigDecimal;

public abstract class CSVObject {
  
  public abstract String getKey();
  public abstract BigDecimal getAggregatePrice();
  
}
