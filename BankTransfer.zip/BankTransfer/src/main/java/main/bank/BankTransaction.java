package main.bank;

import java.io.BufferedReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

import main.bank.process.TransferProcessor;
import main.bank.process.TransferProcessorFactory;

public class BankTransaction {

  private static final String SAMPLE_CSV_FILE_PATH = "src/main/resources/bank_transactions_sample.csv";

  public static void main(String[] args) throws Exception {
    BufferedReader reader = null;
    try {
      reader = Files.newBufferedReader(Paths.get(SAMPLE_CSV_FILE_PATH));
      TransferProcessor procesor = new TransferProcessorFactory().getProcessor(reader, TransferProcessor.CSVObjects.TRANSACTION, TransferProcessor.Format.CSV);
      Map<String, Object> result = procesor.process();
      result.entrySet().stream().forEach(r -> System.out.println(r.getKey() + ": " + r.getValue().toString()));
    } finally {
      if (reader != null)
        reader.close();
    }
  }

}
