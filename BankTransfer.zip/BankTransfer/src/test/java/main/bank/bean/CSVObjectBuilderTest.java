package main.bank.bean;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.File;
import java.io.Reader;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.junit.Test;

import main.bank.process.TransactionCSVProcessorTest;
import main.bank.process.TransferProcessor;
import main.bank.process.TransferProcessor.CSVObjects;

public class CSVObjectBuilderTest {

  @Test
  public void testBuild() throws Exception {
    BufferedReader reader = null;
    try {
      reader = TransactionCSVProcessorTest.getFileReader();
      for (CSVRecord csvRecord : new CSVParser(reader, CSVFormat.DEFAULT.withHeader(TransferProcessor.CSVObjects.TRANSACTION.getHeader()).withFirstRecordAsHeader())) {
        Transaction t = (Transaction) CSVObjectBuilder.build(CSVObjects.TRANSACTION.clazz, csvRecord);
        assertEquals(t.getId(), Integer.parseInt(csvRecord.get("id")));
        assertEquals(t.getLabel(), csvRecord.get("label"));
        assertEquals(t.getDescription(), csvRecord.get("description"));
        assertEquals(t.getAccounttype(), csvRecord.get("accounttype"));
        assertEquals(t.getCurrency(), csvRecord.get("currency"));
        assertEquals(t.getDate(), new java.sql.Date(new SimpleDateFormat("YYYY-MM-DD").parse(csvRecord.get("date")).getTime()));
        assertEquals(t.getAmount(), new BigDecimal(csvRecord.get("amount")));
        assertEquals(t.isDebit(), Boolean.parseBoolean(csvRecord.get("debit")));
      }
    } finally {
      if (reader != null)
        reader.close();
    }

  }

}
