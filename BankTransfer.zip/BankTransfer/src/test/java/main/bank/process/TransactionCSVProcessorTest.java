package main.bank.process;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import java.io.BufferedReader;
import java.io.Reader;
import java.io.StringReader;
import java.math.BigDecimal;
import java.util.HashMap;

import org.junit.Test;

import main.bank.bean.Transaction;
import main.bank.process.TransactionCSVProcessor.TransactionsAmount;

public class TransactionCSVProcessorTest {
  
  public static BufferedReader getFileReader() {
    String test = 
        "id,accounttype,currency,date,description,amount,debit,label\r\n" + 
        "23403,Savings,EUR,2019-02-04 12:00:00,Cheque # 172365,16.00,false,Transfers\r\n";

    Reader inputString = new StringReader(test);
    return new BufferedReader(inputString);
  }
  
  @Test
  public void testProcess() throws Exception {

    BufferedReader reader = null;
    try {
      reader = getFileReader();
      HashMap<String, Object> result = new TransferProcessorFactory().getProcessor(reader, TransferProcessor.CSVObjects.TRANSACTION, TransferProcessor.Format.CSV).process();

      HashMap<String, Object> expected = new HashMap<String, Object>();
      TransactionsAmount t = new TransactionsAmount();
      t.setAmount(new BigDecimal("16.00"));
      expected.put("Transfers", t);

      assertEquals(((TransactionsAmount) result.get("Transfers")).getAmount(), ((TransactionsAmount) expected.get("Transfers")).getAmount());
    } finally {
      if (reader != null)
        reader.close();
    }
  }

  @Test
  public void testAggregateObject() {

    TransactionCSVProcessor.TransactionsAmount ta = new TransactionCSVProcessor.TransactionsAmount();

    Transaction tr = new Transaction();
    tr.setLabel("test");
    tr.setAmount(BigDecimal.ONE);
    ta.aggregateObject(tr);

    assertEquals(1, ta.getCount());
    assertSame(BigDecimal.ONE, ta.getAmount());
  }

}
