package maze;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.File;

import org.junit.Test;

import maze.bean.Maze;
import maze.bean.MazeRunner;
import maze.ir.FindPathFactory;
import maze.ir.FindPathFactory.Type;

public class FindPathTest {
  
  private static int threadNumber = 1;
  

  @Test
  public void test() throws Exception {
    String test = "....................................\r\n" + 
                  "..S...#......................#......\r\n" + 
                  "......#......................#......\r\n" + 
                  ".............................#......\r\n" + 
                  "....................................\r\n" + 
                  "....................................\r\n" + 
                  "..............#.....................\r\n" + 
                  "............#.......................\r\n" + 
                  "..........#.........................\r\n" + 
                  "....................................\r\n" + 
                  ".....................#..........#...\r\n" + 
                  ".....................#....X.....#...\r\n" + 
                  ".....................#..........#...\r\n" + 
                  "....................................";
    
    Maze maze = new FindPathFactory().getFindPath(Type.IS, new ByteArrayInputStream(test.getBytes())).createMaze();
    assertTrue("rrrddrrrrrrrrrrrrrrrrrrrrrdddddddd".equals(new MazeRunner(threadNumber).run(maze)));
    
    maze = new FindPathFactory().getFindPath(Type.FILE, new File("src/main/resources/maze/mazeTest.txt")).createMaze();
    assertTrue("rrrddrrrrrrrrrrrrrrrrrrrrrdddddddd".equals(new MazeRunner(threadNumber).run(maze)));
  }

}
