package maze.bean;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TraceRunnerTest {

  @Test
  public void backtrackPathTest() {
    Coordinate c1 = new Coordinate(1, 1);
    Coordinate c2 = new Coordinate(2, 1, c1);
    assertEquals(TraceRunner.backtrackPath(c2), "d");
  }

}
