package maze.bean;

import static org.junit.Assert.*;

import org.junit.Test;

public class CoordinateTest {

  @Test
  public void getParentTest() {
    Coordinate c1 = new Coordinate(1, 1);
    Coordinate c2 = new Coordinate(2, 2, c1);
    assertEquals(c1, c2.getParent());
  }

  @Test
  public void getDirectionTest() {
    Coordinate c1 = new Coordinate(1, 1);
    Coordinate c2 = new Coordinate(2, 1, c1);
    assertEquals(c2.getDirection(), "d");
  }

  @Test
  public void equalsTest() {
    Coordinate c1 = new Coordinate(1, 1);
    Coordinate c2 = new Coordinate(1, 1);
    assertTrue(c1.equals(c2));
    ;
  }

}
