package maze.ir;

import java.io.File;
import java.io.InputStream;

public class FindPathFactory {
  
  public enum Type {
    FILE, IS
  }
  
  public AbstractFindPathInputReader getFindPath(Type type, Object input) throws Exception {
    if (type.equals(Type.FILE))
      return new FindPathInputReaderFile((File) input);
    
    if (type.equals(Type.IS))
      return new FindPathInputReaderStdIn((InputStream) input);
    
    throw new Exception("Unknown type for factory");
  }

}
