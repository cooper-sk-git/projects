package maze.ir;

import java.io.InputStream;
import java.util.Scanner;

import maze.bean.Maze;

public abstract class AbstractFindPathInputReader {
  
  protected InputStream is;
  
  public Maze createMaze() {
    StringBuilder mazeStr = new StringBuilder();
    try (Scanner input = new Scanner(is)) {
      while (input.hasNextLine()) {
        mazeStr.append(input.nextLine()).append("\n");
      }
    }
    return new Maze(mazeStr.toString()); 
  }

}
