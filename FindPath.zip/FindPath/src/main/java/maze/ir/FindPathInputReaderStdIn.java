package maze.ir;

import java.io.InputStream;

public class FindPathInputReaderStdIn extends AbstractFindPathInputReader {
  
  public FindPathInputReaderStdIn(InputStream is) {
    this.is = is;
  }
}
