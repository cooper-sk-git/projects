package maze.ir;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class FindPathInputReaderFile extends AbstractFindPathInputReader {
  
  public FindPathInputReaderFile(File file) throws FileNotFoundException {
    this.is = new FileInputStream(file);
  }
  
}
