package maze;

import java.io.File;

import maze.bean.Maze;
import maze.bean.MazeRunner;
import maze.ir.FindPathFactory;
import maze.ir.FindPathFactory.Type;

public class FindPath {
  
  private static int threadNumber = 4;

  public static void main(String[] args) throws Exception {
    
    Maze maze = new FindPathFactory().getFindPath(Type.FILE, new File("src/main/resources/maze/maze1.txt")).createMaze();
    System.out.println(new MazeRunner(threadNumber).run(maze));

  }

}
