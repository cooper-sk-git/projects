package maze.bean;

public class Coordinate {

  private int x;
  private int y;
  private Coordinate parent;

  public Coordinate(int x, int y) {
    this.x = x;
    this.y = y;
    this.parent = null;
  }

  public Coordinate(int x, int y, Coordinate parent) {
    this.x = x;
    this.y = y;
    this.parent = parent;
  }

  public int getX() {
    return x;
  }

  public int getY() {
    return y;
  }

  public Coordinate getParent() {
    return parent;
  }

  /**
   * vrati smer cesty u-up, d-down, l-left, r-right podla suradnic parenta
   * @return
   */
  public String getDirection() {
    if (parent == null)
      return "";

    if (x > parent.x)
      return "d";
    else if (x < parent.x)
      return "u";
    else if (y > parent.y)
      return "r";
    else if (y < parent.y)
      return "l";

    throw new IllegalArgumentException("Unknown move");
  }

  @Override
  public boolean equals(Object obj) {
    Coordinate c = (Coordinate) obj;
    return c.getX() == getX() && c.getY() == getY();
  }

}
