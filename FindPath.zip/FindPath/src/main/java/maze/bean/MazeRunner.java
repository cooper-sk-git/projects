package maze.bean;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;

public class MazeRunner {

  private int threadNumber;

  public MazeRunner(int threadNumber) {
    this.threadNumber = threadNumber;
  }

  /**
   * @param maze
   * @return
   * @throws Exception
   */
  public String run(Maze maze) throws Exception {
    Set<Future<String>> result = new HashSet<Future<String>>();
    //do queue pridame startovaci bod
    LinkedBlockingQueue<Coordinate> nextToVisit = new LinkedBlockingQueue<Coordinate>();
    nextToVisit.add(maze.getEntry());

    ExecutorService executorService = null;
    try {
      executorService = Executors.newFixedThreadPool(threadNumber);
      for (int i = 0; i < threadNumber; i++) 
        result.add(executorService.submit(new TraceRunner(nextToVisit, maze)));

      //vratime prvy not null result (z vlakna ktore naslo cestu ako prve)
      for (Future<String> fut : result) {
        String r = fut.get();
        if (r != null && !r.isEmpty())
          return r;
      }
    } finally {
      if (executorService != null)
        executorService.shutdown();
    }
    return null;
  }

}
