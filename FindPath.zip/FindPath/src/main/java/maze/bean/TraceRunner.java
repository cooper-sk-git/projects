package maze.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.Callable;
import java.util.concurrent.LinkedBlockingQueue;

public class TraceRunner implements Callable<String> {

  private static int[][] DIRECTIONS = { { 0, 1 }, { 1, 0 }, { 0, -1 }, { -1, 0 } };

  private LinkedBlockingQueue<Coordinate> nextToVisit;
  private Maze maze;

  public TraceRunner(LinkedBlockingQueue<Coordinate> nextToVisit, Maze maze) {
    this.nextToVisit = nextToVisit;
    this.maze = maze;
  }

  @Override
  public String call() throws InterruptedException {
    try {
      // ak nemame co spracovat tak chvilu pockame
      if (nextToVisit.isEmpty())
        Thread.sleep(100);

      while (!nextToVisit.isEmpty()) {

        Coordinate cur = null;
        try {
          cur = nextToVisit.remove();
        } catch (NoSuchElementException e) {
          // ak medzitym niekto "ukradol" posledny uzol, tak pockame
          Thread.sleep(100);
          continue;
        }

        // ak niektory thread nasiel cestu tak koncime
        if (maze.isFinished())
          break;

        if (!maze.isValidLocation(cur.getX(), cur.getY()))
          continue;

        if (maze.isWall(cur.getX(), cur.getY())) {
          maze.setVisited(cur.getX(), cur.getY(), true);
          continue;
        }

        // ak sme nasli ciel, poznacime to a koncime
        if (maze.isExit(cur.getX(), cur.getY())) {
          maze.setFinished();
          return backtrackPath(cur);
        }

        // pridame do queue vsetkych susedov
        for (int[] direction : DIRECTIONS) {
          maze.setVisited(cur.getX(), cur.getY(), true);
          Coordinate coordinate = new Coordinate(cur.getX() + direction[0], cur.getY() + direction[1], cur);
          if (maze.isValidLocation(coordinate.getX(), coordinate.getY()) && !maze.isWall(coordinate.getX(), coordinate.getY()) && !nextToVisit.contains(coordinate) && !cur.equals(coordinate)) {
            nextToVisit.add(coordinate);
          }
        }
      }
    } finally {
      maze.setFinished();
    }
    return null;
  }

  /**
   * pre dany uzol backtackom vratime celu cestu podla parentov
   * @param cur
   * @return
   */
  public static synchronized String backtrackPath(Coordinate cur) {
    List<Coordinate> path = new ArrayList<Coordinate>();
    Coordinate iter = cur;
    while (iter != null) {
      path.add(iter);
      iter = iter.getParent();
    }
    StringBuilder result = new StringBuilder();
    for (int i = path.size() - 1; i > -1; i--) {
      result.append(path.get(i).getDirection());
    }
    return result.toString();
  }

}
